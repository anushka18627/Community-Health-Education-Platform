// Login function
function login() {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  if (username && password) {
    window.location.href = 'home.html';
  } else {
    alert('Please enter username and password');
  }
}

// Navigate to disease page
function goToDisease() {
  const disease = document.getElementById('disease').value.trim();
  if (disease) {
    localStorage.setItem('selectedDisease', disease);
    window.location.href = 'disease.html';
  } else {
    alert('Please enter a disease name');
  }
}

// Load disease info
window.onload = function() {
  if (window.location.pathname.endsWith('disease.html')) {
    const diseaseName = localStorage.getItem('selectedDisease');
    fetch('data/diseases.json')
      .then(res => res.json())
      .then(data => {
        const disease = data.find(d => d.name.toLowerCase() === diseaseName.toLowerCase());
        if (disease) {
          document.getElementById('disease-name').textContent = disease.name;
          document.getElementById('disease-causes').textContent = disease.causes;
          document.getElementById('disease-type').textContent = disease.type;
          const remediesList = document.getElementById('disease-remedies');
          disease.remedies.forEach(remedy => {
            const li = document.createElement('li');
            li.textContent = remedy;
            remediesList.appendChild(li);
          });
        } else {
          document.getElementById('disease-name').textContent = 'Disease not found';
        }
      });
  }
}